=============================
Google Mobile Ads SDK for iOS
=============================

This is the Google Mobile Ads SDK for iOS.

Requirements:
- Xcode 9.2 or later.
- iOS deployment target of iOS 6.0 or later.

The latest documentation and code samples are available at:
https://firebase.google.com/docs/admob/ios/quick-start
